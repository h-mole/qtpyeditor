#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Created on 2020/9/12
@author: Irony
@site: https://pyqt5.com , https://github.com/892768447
@email: 892768447@qq.com
@file: __init__.py
@description: 
"""

