# -*- coding:utf-8 -*-
# @Time: 2021/1/18 8:53
# @Author: Zhanyi Hou
# @Email: 1295752786@qq.com
# @File: __init__.py.py
from .python import PythonHighlighter
